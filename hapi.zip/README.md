Basic Example
---

```bash
npm run watch # Listen compile .ts files.
npm run build # compile .ts files.

npm run start
```