import React from 'react';
import PropTypes from 'prop-types';
import './style/index.less';
export interface ButtonProps {
    prefixCls?: string;
    type?: string;
    size?: 'large' | 'default' | 'small';
    active?: boolean;
    disabled?: boolean;
    block?: boolean;
    basic?: boolean;
    loading?: boolean;
    className?: string;
    children?: React.ReactNode;
    htmlType?: React.ButtonHTMLAttributes<HTMLButtonElement>['type'];
}
declare function Button(props?: ButtonProps): JSX.Element;
declare namespace Button {
    var defaultProps: {
        prefixCls: string;
        disabled: boolean;
        active: boolean;
        loading: boolean;
        block: boolean;
        basic: boolean;
        htmlType: string;
        type: string;
        size: string;
    };
    var propTypes: {
        prefixCls: PropTypes.Requireable<string>;
        loading: PropTypes.Requireable<boolean>;
        disabled: PropTypes.Requireable<boolean>;
        block: PropTypes.Requireable<boolean>;
        active: PropTypes.Requireable<boolean>;
        basic: PropTypes.Requireable<boolean>;
        htmlType: PropTypes.Requireable<string>;
        type: PropTypes.Requireable<string>;
        size: PropTypes.Requireable<string>;
    };
}
export default Button;
