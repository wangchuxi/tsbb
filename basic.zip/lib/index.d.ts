declare const _default: () => Promise<number>;
export default _default;
