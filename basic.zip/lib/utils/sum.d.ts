export declare function sum(a: number, b: number): number;
