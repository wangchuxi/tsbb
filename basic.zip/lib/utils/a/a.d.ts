/**
 * 这里是注释
 * @param a
 * @param b
 */
export declare function abs(a: number, b: number): number;
