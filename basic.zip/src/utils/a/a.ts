/**
 * 这里是注释
 * @param a
 * @param b
 */
export function abs(a: number, b: number) {
  return a + b;
}
