Basic Example
---

## Quick Start

```shell
$ npx create-kkt my-app 
cd my-app
$ npm install

$ npm run watch # Listen compile .ts files.
$ npm run build # compile .ts files.

$ npm run start
```
